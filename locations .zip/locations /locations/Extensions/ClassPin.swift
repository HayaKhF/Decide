//
//  Pin.swift
//  locations
//
//  Created by Haya on 17/12/1441 AH.
//  Copyright © 1441 Udacity. All rights reserved.
//

import Foundation
import CoreData


@objc(Pin)
public class MyPin: NSManagedObject {
    
    static let namePin = "Pin"
    
    convenience init(latitude: String, longitude: String, context: NSManagedObjectContext) {
        
        if let ent = NSEntityDescription.entity(forEntityName: MyPin.namePin, in: context) {
            
            self.init(entity: ent, insertInto: context)
            self.latitude = latitude
            self.longitude = longitude
        }
        else {
            
            fatalError("Unable to find name!")
        }
    }
    
}


extension MyPin {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<MyPin> {
        return NSFetchRequest<MyPin>(entityName: "Pin")
    }

    @NSManaged public var latitude: String?
    @NSManaged public var longitude: String?
    @NSManaged public var photos: NSSet?

}






extension MyPin {

    @objc(addPhotosObject:)
    @NSManaged public func addToPhotos(_ value: MyPhoto)

    @objc(removePhotosObject:)
    @NSManaged public func removeFromPhotos(_ value: MyPhoto)

    @objc(addPhotos:)
    @NSManaged public func addToPhotos(_ values: NSSet)

    @objc(removePhotos:)
    @NSManaged public func removeFromPhotos(_ values: NSSet)

}
