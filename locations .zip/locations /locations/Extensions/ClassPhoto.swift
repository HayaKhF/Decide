//
//  Photo+CoreDataClass.swift
//  locations
//
//  Created by Haya on 18/12/1441 AH.
//  Copyright © 1441 Udacity. All rights reserved.
//

import Foundation
import CoreData

@objc(Photo)
public class MyPhoto: NSManagedObject {
    
    static let namePhoto = "Photo"
    
    convenience init(title: String, imageUrl: String, forPin: MyPin, context: NSManagedObjectContext) {
        if let ent = NSEntityDescription.entity(forEntityName: MyPhoto.namePhoto, in: context) {
            self.init(entity: ent, insertInto: context)
            self.title = title
            self.image = nil
            self.imageUrl = imageUrl
            self.pin = forPin
        } else {
            fatalError("Unable to find  name!")
        }
    }
    
}



struct PhotosParser: Codable
{
    let photos: Photos
}

struct Photos: Codable {
    let pages: Int
    let photo: [PhotoParser]
}


struct PhotoParser: Codable {
    
    let url: String?
    let title: String
    
    enum CodingKeys: String, CodingKey {
        case url = "url_n"
        case title
    }
}






extension MyPhoto {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<MyPhoto> {
        return NSFetchRequest<MyPhoto>(entityName: "Photo")
    }

    @NSManaged public var image: Data?
    @NSManaged public var title: String?
    @NSManaged public var imageUrl: String?
    @NSManaged public var pin: MyPin?

}
