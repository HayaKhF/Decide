

import UIKit
import MapKit

class MapView: UIViewController, MKMapViewDelegate {
    
    
    
    
  
    
    
    @IBOutlet weak var editeButton: UIBarButtonItem!
    
    @IBOutlet weak var deleteButton: UIBarButtonItem!
    
    @IBOutlet weak var mapView: MKMapView!
    
    var pin_Annotation: MKPointAnnotation? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        deleteButton.isEnabled = false
        if let pins = loadingPins() {
            showingPins(pins)
        }
    }
    
    @IBAction func editFun(_ sender: Any) {
        print("button tapped")
        deleteButton.isEnabled = true
    }
    
    
    @IBAction func deleteFun(_ sender: Any) {
        print("button tapped")
        mapView.removeAnnotations(mapView.annotations)
        print("pins deleted")
    }
    
    
    
    
    
    
    @IBAction func addingPin(_ sender: UILongPressGestureRecognizer) {
        
        let Myloc = sender.location(in: mapView)
        let coordinate_Loc = mapView.convert(Myloc, toCoordinateFrom: mapView)
        
        if sender.state == .began {
            
            pin_Annotation = MKPointAnnotation()
            pin_Annotation!.coordinate = coordinate_Loc
            
            print("Coordinate: \(coordinate_Loc.latitude),\(coordinate_Loc.longitude)")
        
            mapView.addAnnotation(pin_Annotation!)
            
        } else if sender.state == .changed {
            pin_Annotation!.coordinate = coordinate_Loc
        } else if sender.state == .ended {
            
            _ = MyPin(
                latitude: String(pin_Annotation!.coordinate.latitude),
                longitude: String(pin_Annotation!.coordinate.longitude),
                context: DataCore.shared().context
            )
            save()
            
        }
    }
    
    
    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)
    }
    
    
    private func loadingPins() -> [MyPin]? {
        var pins: [MyPin]?
        do {
            try pins = DataCore.shared().fetchAllPins(entityName: MyPin.namePin)
        } catch {
            print("\(#function) error:\(error)")
            showInfo(withTitle: "Error", withMessage: "Error pin location: \(error)")
        }
        return pins
    }
    
    
    private func loadPin(latitude: String, longitude: String) -> MyPin? {
        let pre = NSPredicate(format: "latitude == %@ AND longitude == %@", latitude, longitude)
        var pin: MyPin?
        do {
            try pin = DataCore.shared().fetchPin(pre, entityName: MyPin.namePin)
        } catch {
            showInfo(withTitle: "Error", withMessage: "Error when fitch pin location: \(error)")
        }
        return pin
    }
    
    
    func showingPins(_ pins: [MyPin]) {
        for pin in pins where pin.latitude != nil && pin.longitude != nil {
            let annotation = MKPointAnnotation()
            
            let latitu = Double(pin.latitude!)!
            let longitu = Double(pin.longitude!)!
            annotation.coordinate = CLLocationCoordinate2DMake(latitu, longitu)
            mapView.addAnnotation(annotation)
        }
        mapView.showAnnotations(mapView.annotations, animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is CollectionView {
            guard let pin = sender as? MyPin else {
                return
            }
            let viewc = segue.destination as! CollectionView
            viewc.pin = pin
        }
    }
    
    

}

//extension

extension MapView {
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let reuseId = "pin"
        
        var PinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        
        if PinView == nil {
            PinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            PinView!.canShowCallout = false
            PinView!.pinTintColor = .red
            PinView!.animatesDrop = true
        } else {
            PinView!.annotation = annotation
        }
        
        return PinView
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if control == view.rightCalloutAccessoryView {
            self.showInfo(withMessage: "No link.")
        }
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        
        guard let annotationV = view.annotation else {
            return
        }

        mapView.deselectAnnotation(annotationV, animated: true)
        print("\(#function) latitu \(annotationV.coordinate.latitude) longitu \(annotationV.coordinate.longitude)")
        let latitu = String(annotationV.coordinate.latitude)
        let longitu = String(annotationV.coordinate.longitude)
        let pin = loadPin(latitude: latitu, longitude: longitu)
        performSegue(withIdentifier: "showAlbum", sender: pin)
        }
    }

