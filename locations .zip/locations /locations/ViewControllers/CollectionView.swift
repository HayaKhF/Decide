
import UIKit
import MapKit
import CoreData
//MKMapViewDelegate
class CollectionView: UIViewController, MKMapViewDelegate {
    
//    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var flowLayout: UICollectionViewFlowLayout?
    @IBOutlet weak var newCollectionButton: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var labelStatus: UILabel!
    
    var total_Pages: Int? = nil
    var selected_Indexes = [IndexPath]()
    var inserted_IndexPaths: [IndexPath]!
    var deleted_IndexPaths: [IndexPath]!
    var updated_IndexPaths: [IndexPath]!
 
    var fetched_Results_Controller: NSFetchedResultsController<MyPhoto>!
    var presenting_Alert = false
    var pin: MyPin?
   
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        photosFlowLayout(view.frame.size)


        status("")

        guard let pin = pin else {
            return
        }
        showOnTheMap(pin)
        setupFetchedResultControllerWith(pin)

        if let photos = pin.photos, photos.count == 0 {
            fetchPhotosFromFlikerAPI(pin)
        }
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        photosFlowLayout(size)
    }
    
    
    private func setupFetchedResultControllerWith(_ pin: MyPin) {
        
        let fr = NSFetchRequest<MyPhoto>(entityName: MyPhoto.namePhoto)
        fr.sortDescriptors = []
        fr.predicate = NSPredicate(format: "pin == %@", argumentArray: [pin])
        
        fetched_Results_Controller = NSFetchedResultsController(fetchRequest: fr, managedObjectContext: DataCore.shared().context, sectionNameKeyPath: nil, cacheName: nil)
        fetched_Results_Controller.delegate = self
        
        var err: NSError?
        do {
            try fetched_Results_Controller.performFetch()
        } catch let error as NSError {
            err = error
        }
        
        if let error = err {
            print("Error performing fetch: \(error)")
        }
    }
    
    @IBAction func deleteAc(_ sender: Any) {
        for photos in fetched_Results_Controller.fetchedObjects! {
            DataCore.shared().context.delete(photos)
        }
        save()
        fetchPhotosFromFlikerAPI(pin!)
    }
    
    
    
    
    private func fetchPhotosFromFlikerAPI(_ pin: MyPin) {
        
        let latitu = Double(pin.latitude!)!
        let longitu = Double(pin.longitude!)!
        
        activityIndicator.startAnimating()
        self.status("Loading ..")
        
        Client.shared().search(latitude: latitu, longitude: longitu, totalPages: total_Pages) { (photosParsed, error) in
            self.performUpdates {
                self.activityIndicator.stopAnimating()
                self.labelStatus.text = ""
            }
            if let paresdPhotos = photosParsed {
                self.total_Pages = paresdPhotos.photos.pages
                let totalPhotos = paresdPhotos.photos.photo.count
                print("\(#function) Download \(totalPhotos) photos.")
                self.storePhotos(paresdPhotos.photos.photo, forPin: pin)
                if totalPhotos == 0 {
                    self.status("No found !")
                }
            } else if let error = error {
                print("\(#function) error:\(error)")
                self.showInfo(withTitle: "Error", withMessage: error.localizedDescription)
                self.status("Wrong,")
            }
        }
    }
    
    
    private func status(_ text: String) {
        self.performUpdates {
            self.labelStatus.text = text
        }
    }
    

    private func showOnTheMap(_ pin: MyPin) {

        let lat = Double(pin.latitude!)!
        let lon = Double(pin.longitude!)!
        let locCoord = CLLocationCoordinate2D(latitude: lat, longitude: lon)

        let annotation = MKPointAnnotation()
        annotation.coordinate = locCoord

    }
    
    
    private func storePhotos(_ photos: [PhotoParser], forPin: MyPin) {
        func showErrorMessage(msg: String) {
            showInfo(withTitle: "Error", withMessage: msg)
        }
        
        for photo in photos {
            performUpdates {
                if let url = photo.url {
                    _ = MyPhoto(title: photo.title, imageUrl: url, forPin: forPin, context: DataCore.shared().context)
                    self.save()
                }
            }
        }
    }
    
    
    private func loadingPhotos(using pin: MyPin) -> [MyPhoto]? {
        let predicate = NSPredicate(format: "pin == %@", argumentArray: [pin])
        var photos: [MyPhoto]?
        do {
            try photos = DataCore.shared().fetchPhotos(predicate, entityName: MyPhoto.namePhoto)
        } catch {
            print("\(#function) error:\(error)")
            showInfo(withTitle: "Error", withMessage: "Error loading Photos from disk: \(error)")
        }
        return photos
    }
    
    
    private func photosFlowLayout(_ withSize: CGSize) {
        
        let land_scape = withSize.width > withSize.height
        
        let space: CGFloat = land_scape ? 5 : 3
        let items: CGFloat = land_scape ? 2 : 3
        
        let dimension = (withSize.width - ((items + 1) * space)) / items
        
        flowLayout?.minimumInteritemSpacing = space
        flowLayout?.minimumLineSpacing = space
        flowLayout?.itemSize = CGSize(width: dimension, height: dimension)
        flowLayout?.sectionInset = UIEdgeInsets(top: space, left: space, bottom: space, right: space)
    }
    
    func newColllectionButtonClicked() {
        if selected_Indexes.count > 0 {
            newCollectionButton.setTitle("Remove Selected", for: .normal)
        } else {
            newCollectionButton.setTitle("New Collection", for: .normal)
        }
    }
    

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {

        let reuseId = "pin"

        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView

        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = false
            pinView!.pinTintColor = .red
        } else {
            pinView!.annotation = annotation
        }

        return pinView
    }
}


extension CollectionView: NSFetchedResultsControllerDelegate {
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        inserted_IndexPaths = [IndexPath]()
        deleted_IndexPaths = [IndexPath]()
        updated_IndexPaths = [IndexPath]()
    }
    
    func controller(
        _ controller: NSFetchedResultsController<NSFetchRequestResult>,
        didChange anObject: Any,
        at indexPath: IndexPath?,
        for type: NSFetchedResultsChangeType,
        newIndexPath: IndexPath?) {
        
        switch (type) {
        case .insert:
            inserted_IndexPaths.append(newIndexPath!)
            break
        case .delete:
            deleted_IndexPaths.append(indexPath!)
            break
        case .update:
            updated_IndexPaths.append(indexPath!)
            break
        case .move:
            print("No items available.")
            break
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        
        collectionView.performBatchUpdates({() -> Void in
            
            for indexPath in self.inserted_IndexPaths {
                self.collectionView.insertItems(at: [indexPath])
            }
            
            for indexPath in self.deleted_IndexPaths {
                self.collectionView.deleteItems(at: [indexPath])
            }
            
            for indexPath in self.updated_IndexPaths {
                self.collectionView.reloadItems(at: [indexPath])
            }
            
        }, completion: nil)
    }
    
}



extension CollectionView: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return fetched_Results_Controller.sections?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let sectionInfo = self.fetched_Results_Controller.sections?[section] {
            return sectionInfo.numberOfObjects
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PhotoCell.identifier, for: indexPath) as! PhotoCell
        cell.imageView.image = nil
        cell.activityIndicator.startAnimating()
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        let photo = fetched_Results_Controller.object(at: indexPath)
        let photoViewCell = cell as! PhotoCell
        photoViewCell.url_Photo = photo.imageUrl!
        imageConfig(using: photoViewCell, photo: photo, collectionView: collectionView, index: indexPath)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let photoToDelete = fetched_Results_Controller.object(at: indexPath)
        DataCore.shared().context.delete(photoToDelete)
        save()
    }
    
    func collectionView(_ collectionView: UICollectionView, didEndDisplaying: UICollectionViewCell, forItemAt: IndexPath) {
        
        if collectionView.cellForItem(at: forItemAt) == nil {
            return
        }
        
        let photo = fetched_Results_Controller.object(at: forItemAt)
        if let imageUrl = photo.imageUrl {
            Client.shared().cancelLoading(imageUrl)
        }
    }
    
   
    
    
    private func imageConfig(using cell: PhotoCell, photo: MyPhoto, collectionView: UICollectionView, index: IndexPath) {
        if let imageData = photo.image {
            cell.activityIndicator.stopAnimating()
            cell.imageView.image = UIImage(data: Data(referencing: imageData as NSData))
        } else {
            if let imageUrl = photo.imageUrl {
                cell.activityIndicator.startAnimating()
                Client.shared().loadingImage(imageUrl: imageUrl) { (data, error) in
                    if let _ = error {
                        self.performUpdates {
                            cell.activityIndicator.stopAnimating()
                            self.errorWhileFetching(imageUrl)
                        }
                        return
                    } else if let data = data {
                        self.performUpdates {
                            
                            if let currentCell = collectionView.cellForItem(at: index) as? PhotoCell {
                                if currentCell.url_Photo == imageUrl {
                                    currentCell.imageView.image = UIImage(data: data)
                                    cell.activityIndicator.stopAnimating()
                                }
                            }
                            photo.image = NSData(data: data) as Data
                            DispatchQueue.global(qos: .background).async {
                                self.save()
                            }
                        }
                    }
                }
            }
        }
    }
    
    
    private func errorWhileFetching(_ imageUrl: String) {
        if !self.presenting_Alert {
            self.showInfo(withTitle: "Error", withMessage: "Error while fetching image for this URL: \(imageUrl)", action: {
                self.presenting_Alert = false
            })
        }
        self.presenting_Alert = true
    }
    
}


